/*
 * $ Copyright Cypress Semiconductor $
 */
/** @file
 *  Prototypes of functions for enterprise security commands
 */
#pragma once

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

/********************************************************************/
/* Macros                                                           */
/********************************************************************/
#define ENT_SEC_INFO( x ) printf x
#define ENT_SEC_ERR( x )  printf x

/********************************************************************/
/* Function Prototypes                                              */
/********************************************************************/
void ent_utility_init();

#ifdef __cplusplus
} /*extern "C" */
#endif
