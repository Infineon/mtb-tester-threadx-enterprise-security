/*
 * $ Copyright Cypress Semiconductor $
 */
/** @file
 *
 *  This file provides functions to start and stop tcp server.
 */
#ifndef ENT_SEC_UTILITY_ENT_TCP_SERVER_H_
#define ENT_SEC_UTILITY_ENT_TCP_SERVER_H_

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

/************************************************************************/
/* Function Prototypes                                                  */
/************************************************************************/
cy_rslt_t ent_tcp_server_start(uint16_t port);

cy_rslt_t ent_tcp_server_stop(void);

#ifdef __cplusplus
} /*extern "C" */
#endif

#endif /* ENT_SEC_UTILITY_ENT_TCP_SERVER_H_ */
