/*
 * $ Copyright Cypress Semiconductor $
 */
/** @file
 *
 *  This file provides functions to connect to secure(TLS) server.
 */

#ifndef ENT_SEC_UTILITY_ENT_SECURE_TCP_CLIENT_H_
#define ENT_SEC_UTILITY_ENT_SECURE_TCP_CLIENT_H_

#include <stdint.h>
/*
 * Update the below macros with the actual certificates and keys
 */

/* TLS client certificate. */
#define keyCLIENT_CERTIFICATE_PEM \
"-----BEGIN CERTIFICATE-----\n"\
"-----END CERTIFICATE-----\n"

/* Private key of the TCP client. */
#define keyCLIENT_PRIVATE_KEY_PEM \
"-----BEGIN RSA PRIVATE KEY-----\n"\
"-----END RSA PRIVATE KEY-----\n"

/* TLS server Root certificate. */
#define keySERVER_ROOTCA_PEM \
"-----BEGIN CERTIFICATE-----\n"\
"-----END CERTIFICATE-----\n"

/*******************************************************************************
 * Function Prototype
 ********************************************************************************/
cy_rslt_t ent_secure_tcp_client_connect(char *ip, uint16_t port);

cy_rslt_t ent_secure_tcp_client_disconnect(void);

#endif /* ENT_SEC_UTILITY_ENT_SECURE_TCP_CLIENT_H_ */
