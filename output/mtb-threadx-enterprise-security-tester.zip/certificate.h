/*
 * $ Copyright Cypress Semiconductor $
 */
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

// WPA3 192Bit
#define WPA3_192BIT_ROOT_CERTIFICATE_STRING  \
"-----BEGIN CERTIFICATE-----\r\n" \
"-----END CERTIFICATE-----\r\n";


#define WPA3_192BIT_USER_PRIVATE_KEY_STRING  \
"-----BEGIN EC PRIVATE KEY-----\r\n" \
"-----END EC PRIVATE KEY-----\r\n";

#define WPA3_192BIT_USER_CERTIFICATE_STRING  (const uint8_t*)\
"-----BEGIN CERTIFICATE-----\r\n" \
"-----END CERTIFICATE-----\r\n";


#define WIFI_ROOT_CERTIFICATE_STRING  \
"-----BEGIN CERTIFICATE-----\r\n" \
"-----END CERTIFICATE-----\r\n";


#define WIFI_USER_PRIVATE_KEY_STRING  \
"-----BEGIN RSA PRIVATE KEY-----\r\n" \
"-----END RSA PRIVATE KEY-----\r\n";

#define WIFI_USER_CERTIFICATE_STRING  (const uint8_t*)\
"-----BEGIN CERTIFICATE-----\r\n" \
"-----END CERTIFICATE-----\r\n";


#ifdef __cplusplus
} /*extern "C" */
#endif
